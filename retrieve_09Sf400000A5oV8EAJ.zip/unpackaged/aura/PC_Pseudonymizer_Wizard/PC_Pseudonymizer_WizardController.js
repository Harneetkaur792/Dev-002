({
    doInit: function(cmp) {
        cmp.showSpinner();
        cmp.set("v.isOpen", true);
        var url_string =window.location.href;
        if(typeof sforce !== 'undefined' && sforce && (!!sforce.one)){
            cmp.set("v.lightningError",true);
        }else{
            cmp.set("v.lightningError",false);
        }
        var url = new URL(url_string);
        var strId = url.searchParams.get("id");
       // var sobj=url.searchParams.get("object");
        cmp.set("v.recordMessage", +' Record Id '+strId +' ');
        var action = cmp.get("c.WizardMessage");
        action.setParams({ objId   : strId});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                cmp.hideSpinner();
                cmp.set("v.retMessage",response.getReturnValue().previewMessage);
                cmp.set("v.showpreview",response.getReturnValue().blnPreviewAccess);
                cmp.set("v.showButton",response.getReturnValue().blnisError);
                var count = (response.getReturnValue().previewMessage.match(/:/g) || []).length;
                cmp.set("v.listsize",count);
            }
            else if (state === "INCOMPLETE") {
            }
                else if (state === "ERROR") {
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                        }
                    } else {
                    }
                }
        });
        $A.enqueueAction(action);
        
    },
    saveData: function(cmp) {
        
        var url_string =window.location.href;
        var url = new URL(url_string);
        var strId = url.searchParams.get("id");
       // var sobj=url.searchParams.get("object");
        var action = cmp.get("c.getSourceFieldData");
        action.setParams({ sourceobjId   : strId });
        // the server-side action returns
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                if(response.getReturnValue().includes('INFO ')){
                    var msg = response.getReturnValue().replace("INFO ", "");
                    cmp.set("v.retMessage",msg);
                    return false;
                }
                debugger;
               if( (typeof sforce != 'undefined') && (sforce != null) ) {
                         var action2 = cmp.get("c.deleteHistory");
        action2.setParams({ sRecordId   : strId });
        // the server-side action2 returns
        action2.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
             }
            else if (state === "INCOMPLETE") {
            }
                else if (state === "ERROR") {
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                        }
                    } else {
                    }
                }
        });
        $A.enqueueAction(action2);
                    try{
                        window.open('/'+strId,'_parent');
                    }
                    catch(e){
                    }
                } 
                // Desktop Navigation
                else {
                    var action2 = cmp.get("c.deleteHistory");
        action2.setParams({ sRecordId   : strId });
        // the server-side action2 returns
        action2.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
             }
            else if (state === "INCOMPLETE") {
            }
                else if (state === "ERROR") {
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                        }
                    } else {
                    }
                }
        });
        $A.enqueueAction(action2);
                      window.open('/'+strId,'_parent');
                }
                
                
                /*for chatter*/
                if( (typeof sforce != 'undefined') && (sforce != null) ) {
                         var action2 = cmp.get("c.deleteChatterFeed");
        action2.setParams({ sRecordId   : strId });
        // the server-side action2 returns
        action2.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
             }
            else if (state === "INCOMPLETE") {
            }
                else if (state === "ERROR") {
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                        }
                    } else {
                    }
                }
        });
        $A.enqueueAction(action2);
                    try{
                        window.open('/'+strId,'_parent');
                    }
                    catch(e){
                    }
                } 
                // Desktop Navigation
                else {
                    var action2 = cmp.get("c.deleteChatterFeed");
        action2.setParams({ sRecordId   : strId });
        // the server-side action2 returns
        action2.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
             }
            else if (state === "INCOMPLETE") {
            }
                else if (state === "ERROR") {
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                        }
                    } else {
                    }
                }
        });
        $A.enqueueAction(action2);
                      window.open('/'+strId,'_parent');
                }
                
                /*ends here*/
                
            }
            else if (state === "INCOMPLETE") {
            }
                else if (state === "ERROR") {
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                        }
                    } else {
                    }
                }
        });
        $A.enqueueAction(action);
    },
    cancel: function(cmp) {
        var url_string =window.location.href;
        var url = new URL(url_string);
        var strId = url.searchParams.get("id");
       // var sobj=url.searchParams.get("object");
        if( (typeof sforce != 'undefined') && (sforce != null) ) {
                     sforce.one.navigateToSObject(strId, 'detail');
                } 
                // Desktop Navigation
                else { 
                    window.open('/'+strId,'_parent');
                   }
        cmp.destroy();
    },
    closeModel: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.isOpen", false);
        history.back();
        cmp.destroy();
    },
    showSpinner: function(component, event, helper) {
       // make Spinner attribute true for display loading spinner 
        component.set("v.Spinner", true); 
    },
    
    // this function automatic call by aura:doneWaiting event 
    hideSpinner : function(component,event,helper){
     // make Spinner attribute to false for hide loading spinner    
       component.set("v.Spinner", false);
    },
})